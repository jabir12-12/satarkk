package com.mycompany.satarkk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
