import '/flutter_flow/flutter_flow_util.dart';
import 'comment_component_widget.dart' show CommentComponentWidget;
import 'package:flutter/material.dart';

class CommentComponentModel extends FlutterFlowModel<CommentComponentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
