// Export pages
export '/login/login_widget.dart' show LoginWidget;
export '/home/home_widget.dart' show HomeWidget;
export '/full_news/full_news_widget.dart' show FullNewsWidget;
export '/search_page/search_page_widget.dart' show SearchPageWidget;
export '/create_post/create_post_widget.dart' show CreatePostWidget;
export '/onboarding/onboarding/onboarding_widget.dart' show OnboardingWidget;
export '/test_page/test_page_widget.dart' show TestPageWidget;
