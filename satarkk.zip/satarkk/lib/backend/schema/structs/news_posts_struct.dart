// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';

import '/flutter_flow/flutter_flow_util.dart';

class NewsPostsStruct extends FFFirebaseStruct {
  NewsPostsStruct({
    String? newsHeadline,
    String? newsImage,
    String? newsLink,
    String? newsSource,
    String? newsText,
    String? newsTime,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _newsHeadline = newsHeadline,
        _newsImage = newsImage,
        _newsLink = newsLink,
        _newsSource = newsSource,
        _newsText = newsText,
        _newsTime = newsTime,
        super(firestoreUtilData);

  // "newsHeadline" field.
  String? _newsHeadline;
  String get newsHeadline => _newsHeadline ?? '';
  set newsHeadline(String? val) => _newsHeadline = val;
  bool hasNewsHeadline() => _newsHeadline != null;

  // "newsImage" field.
  String? _newsImage;
  String get newsImage => _newsImage ?? '';
  set newsImage(String? val) => _newsImage = val;
  bool hasNewsImage() => _newsImage != null;

  // "newsLink" field.
  String? _newsLink;
  String get newsLink => _newsLink ?? '';
  set newsLink(String? val) => _newsLink = val;
  bool hasNewsLink() => _newsLink != null;

  // "newsSource" field.
  String? _newsSource;
  String get newsSource => _newsSource ?? '';
  set newsSource(String? val) => _newsSource = val;
  bool hasNewsSource() => _newsSource != null;

  // "newsText" field.
  String? _newsText;
  String get newsText => _newsText ?? '';
  set newsText(String? val) => _newsText = val;
  bool hasNewsText() => _newsText != null;

  // "newsTime" field.
  String? _newsTime;
  String get newsTime => _newsTime ?? '';
  set newsTime(String? val) => _newsTime = val;
  bool hasNewsTime() => _newsTime != null;

  static NewsPostsStruct fromMap(Map<String, dynamic> data) => NewsPostsStruct(
        newsHeadline: data['newsHeadline'] as String?,
        newsImage: data['newsImage'] as String?,
        newsLink: data['newsLink'] as String?,
        newsSource: data['newsSource'] as String?,
        newsText: data['newsText'] as String?,
        newsTime: data['newsTime'] as String?,
      );

  static NewsPostsStruct? maybeFromMap(dynamic data) => data is Map
      ? NewsPostsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'newsHeadline': _newsHeadline,
        'newsImage': _newsImage,
        'newsLink': _newsLink,
        'newsSource': _newsSource,
        'newsText': _newsText,
        'newsTime': _newsTime,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'newsHeadline': serializeParam(
          _newsHeadline,
          ParamType.String,
        ),
        'newsImage': serializeParam(
          _newsImage,
          ParamType.String,
        ),
        'newsLink': serializeParam(
          _newsLink,
          ParamType.String,
        ),
        'newsSource': serializeParam(
          _newsSource,
          ParamType.String,
        ),
        'newsText': serializeParam(
          _newsText,
          ParamType.String,
        ),
        'newsTime': serializeParam(
          _newsTime,
          ParamType.String,
        ),
      }.withoutNulls;

  static NewsPostsStruct fromSerializableMap(Map<String, dynamic> data) =>
      NewsPostsStruct(
        newsHeadline: deserializeParam(
          data['newsHeadline'],
          ParamType.String,
          false,
        ),
        newsImage: deserializeParam(
          data['newsImage'],
          ParamType.String,
          false,
        ),
        newsLink: deserializeParam(
          data['newsLink'],
          ParamType.String,
          false,
        ),
        newsSource: deserializeParam(
          data['newsSource'],
          ParamType.String,
          false,
        ),
        newsText: deserializeParam(
          data['newsText'],
          ParamType.String,
          false,
        ),
        newsTime: deserializeParam(
          data['newsTime'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'NewsPostsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is NewsPostsStruct &&
        newsHeadline == other.newsHeadline &&
        newsImage == other.newsImage &&
        newsLink == other.newsLink &&
        newsSource == other.newsSource &&
        newsText == other.newsText &&
        newsTime == other.newsTime;
  }

  @override
  int get hashCode => const ListEquality().hash(
      [newsHeadline, newsImage, newsLink, newsSource, newsText, newsTime]);
}

NewsPostsStruct createNewsPostsStruct({
  String? newsHeadline,
  String? newsImage,
  String? newsLink,
  String? newsSource,
  String? newsText,
  String? newsTime,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    NewsPostsStruct(
      newsHeadline: newsHeadline,
      newsImage: newsImage,
      newsLink: newsLink,
      newsSource: newsSource,
      newsText: newsText,
      newsTime: newsTime,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

NewsPostsStruct? updateNewsPostsStruct(
  NewsPostsStruct? newsPosts, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    newsPosts
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addNewsPostsStructData(
  Map<String, dynamic> firestoreData,
  NewsPostsStruct? newsPosts,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (newsPosts == null) {
    return;
  }
  if (newsPosts.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && newsPosts.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final newsPostsData = getNewsPostsFirestoreData(newsPosts, forFieldValue);
  final nestedData = newsPostsData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = newsPosts.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getNewsPostsFirestoreData(
  NewsPostsStruct? newsPosts, [
  bool forFieldValue = false,
]) {
  if (newsPosts == null) {
    return {};
  }
  final firestoreData = mapToFirestore(newsPosts.toMap());

  // Add any Firestore field values
  newsPosts.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getNewsPostsListFirestoreData(
  List<NewsPostsStruct>? newsPostss,
) =>
    newsPostss?.map((e) => getNewsPostsFirestoreData(e, true)).toList() ?? [];
