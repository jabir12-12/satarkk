import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class ScamsPostsRecord extends FirestoreRecord {
  ScamsPostsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "comment" field.
  String? _comment;
  String get comment => _comment ?? '';
  bool hasComment() => _comment != null;

  // "details" field.
  String? _details;
  String get details => _details ?? '';
  bool hasDetails() => _details != null;

  // "tag" field.
  String? _tag;
  String get tag => _tag ?? '';
  bool hasTag() => _tag != null;

  // "userid" field.
  String? _userid;
  String get userid => _userid ?? '';
  bool hasUserid() => _userid != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "dp" field.
  String? _dp;
  String get dp => _dp ?? '';
  bool hasDp() => _dp != null;

  // "time" field.
  String? _time;
  String get time => _time ?? '';
  bool hasTime() => _time != null;

  void _initializeFields() {
    _comment = snapshotData['comment'] as String?;
    _details = snapshotData['details'] as String?;
    _tag = snapshotData['tag'] as String?;
    _userid = snapshotData['userid'] as String?;
    _name = snapshotData['name'] as String?;
    _dp = snapshotData['dp'] as String?;
    _time = snapshotData['time'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('scamsPosts');

  static Stream<ScamsPostsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ScamsPostsRecord.fromSnapshot(s));

  static Future<ScamsPostsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ScamsPostsRecord.fromSnapshot(s));

  static ScamsPostsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ScamsPostsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ScamsPostsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ScamsPostsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ScamsPostsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ScamsPostsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createScamsPostsRecordData({
  String? comment,
  String? details,
  String? tag,
  String? userid,
  String? name,
  String? dp,
  String? time,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'comment': comment,
      'details': details,
      'tag': tag,
      'userid': userid,
      'name': name,
      'dp': dp,
      'time': time,
    }.withoutNulls,
  );

  return firestoreData;
}

class ScamsPostsRecordDocumentEquality implements Equality<ScamsPostsRecord> {
  const ScamsPostsRecordDocumentEquality();

  @override
  bool equals(ScamsPostsRecord? e1, ScamsPostsRecord? e2) {
    return e1?.comment == e2?.comment &&
        e1?.details == e2?.details &&
        e1?.tag == e2?.tag &&
        e1?.userid == e2?.userid &&
        e1?.name == e2?.name &&
        e1?.dp == e2?.dp &&
        e1?.time == e2?.time;
  }

  @override
  int hash(ScamsPostsRecord? e) => const ListEquality().hash(
      [e?.comment, e?.details, e?.tag, e?.userid, e?.name, e?.dp, e?.time]);

  @override
  bool isValidKey(Object? o) => o is ScamsPostsRecord;
}
