import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class NewsPostsRecord extends FirestoreRecord {
  NewsPostsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "newsHeadline" field.
  String? _newsHeadline;
  String get newsHeadline => _newsHeadline ?? '';
  bool hasNewsHeadline() => _newsHeadline != null;

  // "newsSource" field.
  String? _newsSource;
  String get newsSource => _newsSource ?? '';
  bool hasNewsSource() => _newsSource != null;

  // "newsText" field.
  String? _newsText;
  String get newsText => _newsText ?? '';
  bool hasNewsText() => _newsText != null;

  // "newsTime" field.
  String? _newsTime;
  String get newsTime => _newsTime ?? '';
  bool hasNewsTime() => _newsTime != null;

  // "newsImage" field.
  String? _newsImage;
  String get newsImage => _newsImage ?? '';
  bool hasNewsImage() => _newsImage != null;

  // "newsLink" field.
  String? _newsLink;
  String get newsLink => _newsLink ?? '';
  bool hasNewsLink() => _newsLink != null;

  void _initializeFields() {
    _newsHeadline = snapshotData['newsHeadline'] as String?;
    _newsSource = snapshotData['newsSource'] as String?;
    _newsText = snapshotData['newsText'] as String?;
    _newsTime = snapshotData['newsTime'] as String?;
    _newsImage = snapshotData['newsImage'] as String?;
    _newsLink = snapshotData['newsLink'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('newsPosts');

  static Stream<NewsPostsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => NewsPostsRecord.fromSnapshot(s));

  static Future<NewsPostsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => NewsPostsRecord.fromSnapshot(s));

  static NewsPostsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      NewsPostsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static NewsPostsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      NewsPostsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'NewsPostsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is NewsPostsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createNewsPostsRecordData({
  String? newsHeadline,
  String? newsSource,
  String? newsText,
  String? newsTime,
  String? newsImage,
  String? newsLink,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'newsHeadline': newsHeadline,
      'newsSource': newsSource,
      'newsText': newsText,
      'newsTime': newsTime,
      'newsImage': newsImage,
      'newsLink': newsLink,
    }.withoutNulls,
  );

  return firestoreData;
}

class NewsPostsRecordDocumentEquality implements Equality<NewsPostsRecord> {
  const NewsPostsRecordDocumentEquality();

  @override
  bool equals(NewsPostsRecord? e1, NewsPostsRecord? e2) {
    return e1?.newsHeadline == e2?.newsHeadline &&
        e1?.newsSource == e2?.newsSource &&
        e1?.newsText == e2?.newsText &&
        e1?.newsTime == e2?.newsTime &&
        e1?.newsImage == e2?.newsImage &&
        e1?.newsLink == e2?.newsLink;
  }

  @override
  int hash(NewsPostsRecord? e) => const ListEquality().hash([
        e?.newsHeadline,
        e?.newsSource,
        e?.newsText,
        e?.newsTime,
        e?.newsImage,
        e?.newsLink
      ]);

  @override
  bool isValidKey(Object? o) => o is NewsPostsRecord;
}
