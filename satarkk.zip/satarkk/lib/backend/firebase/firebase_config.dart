import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyB0u3iAb7j77JOihjrPsMS_TVrkLRfEa2I",
            authDomain: "satarkk-8bfce.firebaseapp.com",
            projectId: "satarkk-8bfce",
            storageBucket: "satarkk-8bfce.appspot.com",
            messagingSenderId: "135830162089",
            appId: "1:135830162089:web:9bb7e939bd2260f781f7b8",
            measurementId: "G-FQ2QBT44SW"));
  } else {
    await Firebase.initializeApp();
  }
}
